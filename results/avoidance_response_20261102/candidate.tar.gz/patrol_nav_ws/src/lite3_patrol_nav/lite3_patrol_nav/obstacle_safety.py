"""Local grid veto, independent of map projection and Nav2 costmap updates.

Not an independent sensor: camera/VOA faults still stop this path. Commands may
only be multiplied by 0, .5 or 1; this module never chooses a steering direction.
Braking constants require field measurement before motion acceptance.
"""
from collections import deque
import math
from pathlib import Path

import numpy as np
import yaml

from .voa_grid import decode_grid


def footprint_extents(costmap):
    vertices = costmap['footprint']
    if isinstance(vertices, str):
        vertices = yaml.safe_load(vertices)
    vertices = np.asarray(vertices, dtype=float)
    padding = float(costmap.get('footprint_padding', 0.))
    if (vertices.ndim != 2 or vertices.shape[1] != 2 or len(vertices) < 3
            or not np.isfinite(vertices).all() or not math.isfinite(padding) or padding < 0):
        raise ValueError('invalid footprint')
    # A conservative centered bounding rectangle also supports asymmetric feet.
    hx, hy = np.max(np.abs(vertices), axis=0) + padding
    if not (.15 <= hx <= 1.0 and .1 <= hy <= .8):
        raise ValueError('unsupported footprint extents')
    return float(hx), float(hy)


def terminal_extents(hx, hy, yaw_tolerance, xy_tolerance, margin):
    """Cover all accepted terminal yaw/XY errors, in goal-oriented axes."""
    if not (0 <= yaw_tolerance <= math.pi and 0 <= xy_tolerance <= .5 and 0 <= margin <= .2):
        raise ValueError('invalid terminal tolerances')
    angles = [0., yaw_tolerance]
    angles += [a for a in (math.atan2(hy, hx), math.atan2(hx, hy), math.pi/2)
               if a <= yaw_tolerance]
    x = max(hx*abs(math.cos(a))+hy*abs(math.sin(a)) for a in angles)
    y = max(hy*abs(math.cos(a))+hx*abs(math.sin(a)) for a in angles)
    return x+xy_tolerance+margin, y+xy_tolerance+margin


def rectangle_hits(xy, center, yaw, half_extents, cell_radius=0.):
    d = np.asarray(xy, dtype=float).reshape(-1, 2) - center
    c, s = math.cos(yaw), math.sin(yaw)
    local = d @ np.array([[c, -s], [s, c]])
    return ((abs(local[:, 0]) <= half_extents[0]+cell_radius)
            & (abs(local[:, 1]) <= half_extents[1]+cell_radius))


class LocalGridSafety:
    def __init__(self, hx, hy, minimum, settings, max_v=.15, max_w=.4):
        self.hx, self.hy, self.minimum = hx, hy, minimum
        self.settings = settings
        for key in ('grid_timeout_s', 'reaction_s', 'linear_braking_mps2',
                    'angular_braking_radps2', 'margin_m', 'prediction_s'):
            if not math.isfinite(float(settings[key])) or float(settings[key]) <= 0:
                raise ValueError('invalid local stop setting '+key)
        if not (.05 <= settings['grid_timeout_s'] <= .25
                and .03 <= settings['margin_m'] <= .2
                and .5 <= settings['prediction_s'] <= 3
                and .05 <= settings['linear_braking_mps2'] <= .25
                and .1 <= settings['angular_braking_radps2'] <= .5
                and 1 <= settings['release_clear_frames'] <= 10):
            raise ValueError('unsafe local stop configuration')
        if not (0 < minimum <= .10 and 0 < max_v <= .15 and 0 < max_w <= .4):
            raise ValueError('invalid local stop geometry/speed')
        self.max_v, self.max_w = max_v, max_w
        self.stamp = 0.
        self.xyz = None
        self.error = 'no_grid'
        self.history = deque(maxlen=40)
        self.stopped = False
        self.clear_count = 0
        self.clear_stamp = 0.

    @classmethod
    def from_files(cls, nav_file, voa_file, response_file):
        nav = yaml.safe_load(Path(nav_file).read_text())
        local = nav['local_costmap']['local_costmap']['ros__parameters']
        global_map = nav['global_costmap']['global_costmap']['ros__parameters']
        extents = np.maximum(footprint_extents(local), footprint_extents(global_map))
        voa = yaml.safe_load(Path(voa_file).read_text())['/**']['ros__parameters']
        # Never use less than either the Nav2 or factory collision rectangle.
        hx = max(float(extents[0]), float(voa['kRobotLengthM'])/2)
        hy = max(float(extents[1]), float(voa['kRobotWidthM'])/2)
        config = yaml.safe_load(Path(response_file).read_text())
        follow = nav['controller_server']['ros__parameters']['FollowPath']
        if follow['min_vel_x'] < 0 or follow['min_vel_y'] != 0 or follow['max_vel_y'] != 0:
            raise ValueError('camera-only local stop requires forward-only navigation')
        return cls(hx, hy, float(voa['kObstatleHeight']), config['local_stop'],
                   float(follow['max_vel_x']), float(follow['max_vel_theta']))

    def update(self, msg, now):
        try:
            stamp = msg.header.stamp.sec + msg.header.stamp.nanosec/1e9
            if (msg.header.stamp.sec < 0 or not 0 <= msg.header.stamp.nanosec < 1000000000
                    or not math.isfinite(stamp) or not -.05 <= now-stamp <= self.settings['grid_timeout_s']):
                return False
            if stamp <= self.stamp:
                return False
            xyz, resolution = decode_grid(msg)
            self.xyz, self.resolution, self.stamp = xyz, resolution, stamp
            self.error = ''
            return True
        except (ValueError, TypeError, AttributeError, IndexError) as error:
            self.xyz = None
            self.error = str(error)
            return False

    def healthy(self, now):
        return (self.xyz is not None and not self.error
                and -.05 <= now-self.stamp <= self.settings['grid_timeout_s'])

    def remember_output(self, command, now):
        if any(abs(v) > 1e-6 for v in command):
            self.history.append((now, tuple(command)))

    def collision(self, command, age, horizon):
        vx, vy, wz = command
        if vx < -1e-6 or abs(vy) > 1e-6:
            return 'unverified_reverse_or_lateral_coverage'
        speed = math.hypot(vx, vy)
        radius = math.hypot(self.hx, self.hy)
        # Account for cell extent, inter-sample sweep, and unknown motion since
        # the grid's sensor timestamp. No map TF or restamping is involved.
        steps = max(1, math.ceil((speed+radius*abs(wz))*horizon/.02))
        dt = horizon/steps
        margin = (self.settings['margin_m']+self.resolution/math.sqrt(2)
                  +(self.max_v+radius*self.max_w)*max(0., age)
                  +(speed+radius*abs(wz))*dt/2)
        finite = np.isfinite(self.xyz[:, 2])
        obstacle = np.zeros(len(self.xyz), dtype=bool)
        obstacle[finite] = self.xyz[finite, 2] > self.minimum
        unknown = ~finite
        # The currently occupied body interior is self-occluded. Unknown cells
        # there cannot establish free space elsewhere; check all newly swept
        # unknown space. Measured obstacles inside the body still stop motion.
        unknown &= ~rectangle_hits(self.xyz[:, :2], (0., 0.), 0., (self.hx, self.hy))
        danger = obstacle | unknown
        xy = self.xyz[danger, :2]
        lo = self.xyz[:, :2].min(axis=0)-self.resolution/2
        hi = self.xyz[:, :2].max(axis=0)+self.resolution/2
        for t in np.linspace(0, horizon, steps+1):
            theta = wz*t
            if abs(wz) < 1e-7:
                center = np.array([vx*t, vy*t])
            else:
                center = np.array([(vx*math.sin(theta)+vy*(math.cos(theta)-1))/wz,
                                   (vx*(1-math.cos(theta))+vy*math.sin(theta))/wz])
            c, s = abs(math.cos(theta)), abs(math.sin(theta))
            bounds = np.array([c*(self.hx+margin)+s*(self.hy+margin),
                               s*(self.hx+margin)+c*(self.hy+margin)])
            if np.any(center-bounds < lo) or np.any(center+bounds > hi):
                return 'outside_observed_grid'
            if rectangle_hits(xy, center, theta, (self.hx+margin, self.hy+margin)).any():
                return 'obstacle_or_unknown_in_swept_footprint'
        return ''

    def limit(self, command, now):
        if not self.healthy(now):
            return 0., 'local_grid_stale_or_invalid'
        if not all(math.isfinite(v) for v in command):
            return 0., 'invalid_command'
        age = max(0., now-self.stamp)
        reaction = self.settings['reaction_s']
        braking = max(self.max_v/self.settings['linear_braking_mps2'],
                      self.max_w/self.settings['angular_braking_radps2'])+reaction
        while self.history and now-self.history[0][0] > braking:
            self.history.popleft()
        # Recent published motion may still be decelerating after a command
        # change or zero output. It must not disappear from the collision test.
        recent = {command: stamp for stamp, command in self.history}
        for previous, stamp in recent.items():
            remaining = max(0., braking-(now-stamp))
            if self.collision(previous, age, remaining):
                self.stopped = True; self.clear_count = 0
                return 0., 'recent_motion_braking_envelope_blocked'
        if command == (0., 0., 0.):
            return 1., 'zero_command'
        reason = ''
        for scale in (1., .5):
            candidate = tuple(v*scale for v in command)
            horizon = max(self.settings['prediction_s'], reaction+max(
                abs(candidate[0])/self.settings['linear_braking_mps2'],
                abs(candidate[2])/self.settings['angular_braking_radps2']))
            reason = self.collision(candidate, age, horizon)
            if not reason:
                if self.stopped:
                    if self.stamp != self.clear_stamp:
                        self.clear_stamp = self.stamp; self.clear_count += 1
                    if self.clear_count < self.settings['release_clear_frames']:
                        return 0., 'waiting_for_distinct_clear_frames'
                self.stopped = False; self.clear_count = 0
                return scale, 'clear' if scale == 1 else 'same_path_slowdown'
        self.stopped = True; self.clear_count = 0
        return 0., reason
