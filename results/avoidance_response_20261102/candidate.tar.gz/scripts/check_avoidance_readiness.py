#!/usr/bin/env python3
"""Read-only timing/zero-motion acceptance, including local-grid shadow checks.

No publisher, service, ARM request or navigation goal is created. Costmap topic
arrival cadence does not prove its internal update deadline or a safe path.
"""
import argparse
import json
from pathlib import Path
import sys
import time

import numpy as np


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--seconds', type=float, default=60.)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--nav-config', type=Path, required=True)
    p.add_argument('--perception-only', action='store_true')
    args = p.parse_args()
    if args.output.exists() or args.seconds < 5:
        p.error('use a new output path and at least five seconds')
    root = Path(__file__).resolve().parents[1]
    sys.path.insert(0,str(root/'patrol_nav_ws/src/lite3_patrol_nav'))
    from lite3_patrol_nav.obstacle_safety import LocalGridSafety
    local = LocalGridSafety.from_files(args.nav_config,root/'navigation/vendor_voa.yaml',
                                      root/'navigation/obstacle_response.yaml')
    import rclpy
    from grid_map_msgs.msg import GridMap
    from geometry_msgs.msg import Twist
    from nav_msgs.msg import OccupancyGrid
    from sensor_msgs.msg import PointCloud2
    from std_msgs.msg import Bool, Header, String
    from rclpy.qos import QoSProfile, ReliabilityPolicy
    rclpy.init(); node = rclpy.create_node('avoidance_readonly_acceptance')
    streams = {}; shadow = []; errors = []; moving = []; armed = []
    def receive(key, msg):
        now = time.monotonic()
        data = streams.setdefault(key,dict(arrivals=[],ages=[]))
        data['arrivals'].append(now)
        header = msg if key == 'heartbeat' else getattr(msg,'header',None)
        if header is not None and key in ('grid','heartbeat','projection'):
            stamp = header.stamp.sec+header.stamp.nanosec/1e9
            data['ages'].append(now-stamp)
        if key == 'grid':
            try:
                if not local.update(msg,now):
                    errors.append('local_grid_rejected')
                else:
                    started = time.monotonic()
                    scale,reason = local.limit((.10,0.,0.),now)
                    shadow.append(dict(scale=scale,reason=reason,evaluation_s=time.monotonic()-started))
            except Exception as error:
                errors.append(type(error).__name__+':'+str(error))
        if key == 'corrected' and any(abs(v)>1e-6 for v in (msg.linear.x,msg.linear.y,msg.angular.z)):
            moving.append(now)
        if key == 'armed' and msg.data:
            armed.append(now)
    sources = {
        'grid': (GridMap,'/patrol/voa/grid_map'),
        'heartbeat': (Header,'/patrol/voa/costmap_heartbeat'),
        'projection': (PointCloud2,'/patrol/voa/costmap_obstacles'),
        'local': (OccupancyGrid,'/local_costmap/costmap'),
        'global': (OccupancyGrid,'/global_costmap/costmap'),
        'local_safety': (String,'/patrol/voa/local_safety'),
        'raw': (Twist,'/patrol/cmd_vel_raw'),
        'corrected': (Twist,'/cmd_vel_corrected'),
        'armed': (Bool,'/patrol/armed')}
    qos = QoSProfile(depth=1,reliability=ReliabilityPolicy.BEST_EFFORT)
    subs = [node.create_subscription(kind,topic,lambda m,k=k:receive(k,m),qos)
            for k,(kind,topic) in sources.items()]
    started = time.monotonic(); end = started+args.seconds
    while time.monotonic()<end:
        rclpy.spin_once(node,timeout_sec=.02)
    now = time.monotonic(); summary = {}
    for key,data in streams.items():
        arrivals = data['arrivals']; gaps = np.diff(arrivals+[now])
        summary[key] = dict(count=len(arrivals),max_gap_s=float(max(gaps,default=0)),
                            first_arrival_s=arrivals[0]-started)
        if data['ages']:
            summary[key].update(source_age_p95_s=float(np.percentile(data['ages'],95)),
                                source_age_max_s=float(max(data['ages'])))
    failures = list(dict.fromkeys(errors))
    required = {'grid': .25} if args.perception_only else {
        'grid': .25,'heartbeat':.5,'projection':.5,'local':1.,'global':1.,'local_safety':.25,
        'corrected':.25,'armed':.5}
    for key,deadline in required.items():
        if key not in summary or summary[key]['count'] < 3:
            failures.append(key+':missing_or_insufficient')
        elif summary[key]['max_gap_s'] > deadline:
            failures.append(key+':arrival_gap')
        if summary.get(key,{}).get('source_age_max_s',0) > deadline:
            failures.append(key+':source_stale')
    if moving or armed:
        failures.append('not_a_disarmed_stationary_session')
    if shadow and max(x['evaluation_s'] for x in shadow) > .05:
        failures.append('local_shadow_evaluation_over_50ms')
    report = dict(scope='stationary perception only' if args.perception_only else 'stationary timing; dynamic/path acceptance separate',
        passed=not failures,failures=failures,seconds=now-started,streams=summary,
        shadow=dict(count=len(shadow),stops=sum(x['scale']==0 for x in shadow),
                    slowdowns=sum(x['scale']==.5 for x in shadow),
                    max_evaluation_s=max((x['evaluation_s'] for x in shadow),default=None),
                    note='hypothetical .10 m/s command, NEVER published; stops can be legitimate obstacles'),
        nonzero_corrected_count=len(moving),armed_count=len(armed),
        motor_publishers={t:node.count_publishers(t) for t in ['/cmd_vel','/cmd_vel_corrected']})
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(report,indent=2));print(json.dumps(report,ensure_ascii=False))
    node.destroy_node();rclpy.shutdown()
    return 0 if report['passed'] else 1


if __name__=='__main__':
    raise SystemExit(main())
