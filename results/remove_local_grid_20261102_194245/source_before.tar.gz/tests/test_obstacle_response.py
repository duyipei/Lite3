"""Synthetic geometry and actual gate integration; no robot motion or ROS bus."""
import copy
import importlib.util
import json
import math
from pathlib import Path
import sys
from types import SimpleNamespace as NS
import time
from unittest.mock import patch

import numpy as np
import pytest
import yaml

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'patrol_nav_ws/src/lite3_patrol_nav'))
sys.path.insert(0, str(ROOT/'scripts'))
from lite3_patrol_nav.obstacle_safety import LocalGridSafety, terminal_extents
from test_voa_costmap_bridge import grid
from make_dynamic_nav2_config import build

PROFILE = ROOT/'navigation/obstacle_response.yaml'
SETTINGS = yaml.safe_load(PROFILE.read_text())['local_stop']


def scene(points=(), stamp=100., order='F', start=(0, 0)):
    data = np.zeros((120, 80))
    for x, y, z in points:
        data[int(math.floor((3-x)/.05)), int(math.floor((2-y)/.05))] = z
    msg = grid(data, order=order, start=start, stamp=stamp)
    msg.info.resolution = .05
    msg.info.length_x, msg.info.length_y = 6., 4.
    mask = copy.deepcopy(msg.data[0])
    mask.data = np.isfinite(mask.data).astype(float).tolist()
    msg.layers.append('observation_validity'); msg.data.append(mask)
    return msg


def guard(points=(), stamp=100.):
    g = LocalGridSafety(.35, .25, .1, copy.deepcopy(SETTINGS))
    assert g.update(scene(points, stamp), stamp+.02)
    return g


@pytest.mark.parametrize('points,scale', [([], 1.), ([(.55,0,.2)], .5),
    ([(.40,0,.2)], 0.), ([(.45,.6,.2)], 1.), ([(.40,0,float('nan'))], 0.)])
def test_local_clear_slow_stop_and_off_path_obstacle(points, scale):
    assert guard(points).limit((.15,0.,0.), 100.02)[0] == scale


def test_passable_corridor_and_true_footprint_collision():
    walls = [(x,y,.2) for x in np.arange(-.5,1.5,.05) for y in (-.45,.45)]
    assert guard(walls).limit((.15,0.,0.),100.02)[0] == 1.
    narrow = [(x,y,.2) for x in np.arange(-.5,1.5,.05) for y in (-.25,.25)]
    assert guard(narrow).limit((.15,0.,0.),100.02)[0] == 0.


def test_no_map_tf_needed_and_circular_layout_preserves_stop():
    msg = scene([(.4,0,.2)], order='C', start=(113,73))
    g = guard()
    msg.header.stamp.nanosec = 50000000
    assert g.update(msg,100.06)
    assert g.limit((.15,0.,0.),100.06)[0] == 0.


def test_replay_stale_invalid_and_forward_only():
    g = guard()
    assert not g.update(scene(stamp=99.),100.02)
    assert g.stamp == 100.
    assert not g.healthy(100.251)
    assert g.limit((.1,0.,0.),100.3)[0] == 0.
    assert g.limit((-.08,0.,0.),100.02)[0] == 0.
    malformed = scene(stamp=100.1); malformed.data[0].data.pop()
    assert not g.update(malformed,100.11)
    assert not g.healthy(100.11)


def test_missing_or_cv_filled_observation_mask_fails_closed():
    g = guard()
    msg = scene(stamp=100.04)
    msg.layers.pop(); msg.data.pop()
    assert not g.update(msg,100.05)
    assert not g.healthy(100.05)
    msg = scene([(.4,0,float('nan'))],stamp=100.08)
    # Reproduce the factory CV conversion defect: unobserved NaN becomes
    # minimum finite elevation, while independent validity remains zero.
    a = np.asarray(msg.data[0].data)
    a[~np.isfinite(a)] = -.43
    msg.data[0].data = a.tolist()
    assert not g.update(msg,100.09)
    assert not g.healthy(100.09)


def test_planner_known_only_does_not_invent_unknown_walls_or_clear_obstacles():
    from lite3_patrol_nav.voa_grid import grid_obstacles
    msg = scene([(.4,0,float('nan')),(.8,0,.2)])
    known,stats = grid_obstacles(msg,.1,include_unknown=False)
    assert len(known) == 1 and stats['unknown'] == 1
    conservative,_ = grid_obstacles(msg,.1,include_unknown=True)
    assert len(conservative) == 2
    # Same missing observation still vetoes local motion, not fabricated free.
    assert guard([(.4,0,float('nan'))]).limit((.1,0.,0.),100.02)[0] == 0.


def test_stop_release_requires_distinct_clear_sensor_frames():
    g = guard([(.4,0,.2)])
    assert g.limit((.15,0.,0.),100.02)[0] == 0.
    assert g.update(scene(stamp=100.04),100.05)
    for _ in range(5):
        assert g.limit((.15,0.,0.),100.05)[0] == 0.
    assert g.update(scene(stamp=100.08),100.09)
    assert g.limit((.15,0.,0.),100.09)[0] == 0.
    assert g.update(scene(stamp=100.12),100.13)
    assert g.limit((.15,0.,0.),100.13)[0] == 1.


def test_recent_output_momentum_is_not_removed_by_new_command():
    g = guard([(.4,0,.2)])
    g.remember_output((.15,0.,0.),100.)
    assert g.limit((0.,0.,.2),100.02) == (0.,'recent_motion_braking_envelope_blocked')


def test_rotation_sweep_checks_corners_not_only_robot_center():
    g = guard([(.3,.4,.2)])
    scale, reason = g.limit((0.,0.,.4),100.02)
    assert scale < 1.
    assert reason != 'clear'


@pytest.mark.parametrize('height', [.10, .16, .20])
def test_true_height_obstacles_are_never_removed_to_improve_passage(height):
    # Float32 .10 is strictly above the factory double threshold, matching its
    # original predicate. No obstacle threshold has been raised by this change.
    assert guard([(.4,0,height)]).limit((.15,0.,0.),100.02)[0] == 0.


def test_flat_floor_is_not_an_obstacle_and_unknown_body_is_not_free_space_ahead():
    assert guard([(.4,0,.099)]).limit((.15,0.,0.),100.02)[0] == 1.
    assert guard([(0,0,float('nan'))]).limit((.15,0.,0.),100.02)[0] == 1.
    assert guard([(.4,0,float('nan'))]).limit((.15,0.,0.),100.02)[0] == 0.


def test_held_out_dense_trajectory_oracle_detects_no_missed_physical_contact():
    # Independent dense continuous-path approximation; seed/locations do not
    # reuse the hand-selected pass/stop fixtures used to tune margins.
    rng = np.random.default_rng(19342)
    for _ in range(24):
        p = rng.uniform([.15,-.55],[.8,.55])
        g = guard([(p[0],p[1],.20)])
        cmd = (float(rng.uniform(.04,.15)),0.,float(rng.uniform(-.4,.4)))
        scale,_ = g.limit(cmd,100.02)
        if scale == 0:
            continue
        vx,_,w = np.array(cmd)*scale
        t = np.linspace(0,1.,2001)
        if abs(w) < 1e-7:
            x,y = vx*t,np.zeros(len(t))
        else:
            x,y = vx*np.sin(w*t)/w,vx*(1-np.cos(w*t))/w
        # Use the actual quantized occupied cell rather than its requested
        # coordinate. The oracle checks the unpadded physical rectangle.
        point = g.xyz[np.isfinite(g.xyz[:,2]) & (g.xyz[:,2]>.1)][0,:2]
        dx,dy = point[0]-x,point[1]-y
        local_x = dx*np.cos(w*t)+dy*np.sin(w*t)
        local_y = -dx*np.sin(w*t)+dy*np.cos(w*t)
        assert not ((abs(local_x)<=.35)&(abs(local_y)<=.25)).any()


def test_profile_changes_only_private_overlay_and_uses_shared_goal_tolerance(tmp_path):
    base = yaml.safe_load((ROOT/'navigation/patrol_map_20261031_01_area_v2_review/nav2_safe.yaml').read_text())
    before = copy.deepcopy(base)
    result = build(base,ROOT/'navigation/navigate_dynamic_obstacles.xml',factory_only=True)
    assert base == before
    for key,hz in [('local_costmap',5.),('global_costmap',2.)]:
        c = result[key][key]['ros__parameters']
        assert c['update_frequency'] >= hz
        assert c['publish_frequency'] == 2.
        assert c['inflation_layer']['inflation_radius'] == .50
        assert c['footprint'] == base[key][key]['ros__parameters']['footprint']
    controller = result['controller_server']['ros__parameters']
    assert controller['goal_checker']['xy_goal_tolerance'] == .12
    assert controller['FollowPath']['xy_goal_tolerance'] == .12
    assert controller['FollowPath']['min_vel_x'] == 0.
    assert controller['progress_checker']['movement_time_allowance'] == 15.
    nav = tmp_path/'nav.yaml'; nav.write_text(yaml.safe_dump(result))
    safety = LocalGridSafety.from_files(nav,ROOT/'navigation/vendor_voa.yaml',PROFILE)
    assert safety.hx >= .35 and safety.hy >= .25


def test_actual_gate_stops_without_waiting_for_costmap_heartbeat_failure():
    from test_factory_voa_mode import FactoryGateTests
    fixture = FactoryGateTests(); fixture.setUp()
    try:
        g = fixture.gate
        g.get_publishers_info_by_topic = lambda topic: [NS(node_name='controller_server'),NS(node_name='unknown_teleop')]
        assert g.sensor_health()[1] == 'nav_command_publisher_conflict'
        g.get_publishers_info_by_topic = lambda topic: [NS(node_name='controller_server'),NS(node_name='recoveries_server')]
        g.require_local_grid_stop = True
        g.local_safety = guard(stamp=10.)
        g.local_safety_diagnostics = g.create_publisher(NS,'/patrol/voa/local_safety',1)
        g.counts['/patrol/voa/grid_map'] = 1
        fixture.heartbeat()
        assert fixture.arm().success
        g.goal_active_callback(NS(data=True))
        command = fixture.module.Twist(); command.linear.x = .15; g.raw_callback(command)
        assert g.local_safety.update(scene([(.4,0,.2)],stamp=10.01),10.02)
        g.clock_time = 10.02
        g.timer_callback()
        assert fixture.output() == (0.,0.,0.)
        assert g.armed  # Physical obstruction waits; it does not re-ARM a fault.
        d = json.loads(g.outputs['/patrol/voa/local_safety'][-1].data)
        assert d['scale'] == 0
        assert d['evaluation_s'] >= 0
        g.clock_time = 10.3
        fixture.heartbeat(10.3)  # Map bridge healthy; LOCAL grid is stale.
        g.timer_callback()
        assert not g.armed
        assert g.fault == 'local_grid_stale_or_invalid'
        assert fixture.output() == (0.,0.,0.)
    finally:
        fixture.doCleanups()


def test_actual_goal_bridge_oriented_extent_unknown_boundary_and_empty_cloud():
    from test_patrol_route import Tests
    from costmap_ground_filter import cloud_xyz
    fixture = Tests(); fixture.setUp()
    b = fixture.bridge
    try:
        b.goal_geometry = terminal_extents(.35,.25,.2,.12,.03)
        b.map_msg = NS(header=NS(frame_id='map'), info=NS(resolution=.1,width=50,height=50,
            origin=NS(position=NS(x=-2.5,y=-2.5),orientation=NS(x=0.,y=0.,z=0.,w=1.))),data=[0]*2500)
        b.require_voa_obstacles = False
        assert b.goal_clearance(0.,0.,0.)[0]
        assert not b.goal_clearance(2.4,0.,0.)[0]
        b.map_msg.data[25*50+25] = -1
        assert b.goal_clearance(0.,0.,0.)[1] == 'goal_footprint_contains_unknown'
        b.map_msg.data[25*50+25] = 0
        # Beyond side extent at yaw zero, but in front extent after 90 deg.
        col,row = 25,30
        b.map_msg.data[row*50+col] = 100
        assert b.goal_clearance(0.,0.,0.)[0]
        assert not b.goal_clearance(0.,0.,math.pi/2)[0]
        b.map_msg.data[row*50+col] = 0
        b.require_voa_obstacles = True
        import test_patrol_route
        now = test_patrol_route.BUS.now
        b.voa_cloud_time = now
        b.voa_cloud = NS(header=NS(frame_id='map',stamp=NS(sec=int(now),nanosec=0)),
            fields=[NS(name=k,datatype=7,offset=i*4) for i,k in enumerate(('x','y','z'))],
            is_bigendian=False,height=1,width=0,point_step=12,row_step=0,data=b'')
        assert b.goal_clearance(0.,0.,0.)[0]  # Fresh observed empty cloud is valid.
        b.voa_cloud.header.stamp.sec -= 1
        assert b.goal_clearance(0.,0.,0.)[1] == 'voa_obstacles_stale'
    finally:
        fixture.doCleanups()


def test_goal_bridge_constructor_with_actual_dynamic_yaml_preserves_ros_path_type(tmp_path):
    # Exercise the real startup branch. Setting goal_geometry manually misses
    # filesystem Path being shadowed by nav_msgs.msg.Path at import time.
    from test_patrol_route import bridge, Node, Message
    base = yaml.safe_load((ROOT/'navigation/patrol_map_20261031_01_area_v2_review/nav2_safe.yaml').read_text())
    nav = tmp_path/'nav2_dynamic.yaml'
    nav.write_text(yaml.safe_dump(build(base,ROOT/'navigation/navigate_dynamic_obstacles.xml',factory_only=True)))
    overrides = {'goal_nav2_file':str(nav),'goal_response_file':str(PROFILE)}
    declare = Node.declare_parameter
    publisher = Node.create_publisher
    kinds = {}
    def with_overrides(self,key,default):
        return declare(self,key,overrides.get(key,default))
    def capture_kind(self,kind,topic,qos):
        kinds[topic] = kind
        return publisher(self,kind,topic,qos)
    with patch.object(Node,'declare_parameter',with_overrides), patch.object(Node,'create_publisher',capture_kind):
        b = bridge.GoalPoseBridge()
    assert b.goal_geometry[0] > .5
    assert b.goal_geometry[1] > .4
    assert kinds['/plan'] is Message
    assert bridge.Path is Message
