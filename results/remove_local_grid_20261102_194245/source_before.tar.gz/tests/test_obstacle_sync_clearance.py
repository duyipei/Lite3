"""Concurrency, freshness and near-obstacle decisions using actual code."""
import json
import threading
import time
from types import SimpleNamespace as NS

import numpy as np

from test_obstacle_response import guard, scene
from test_voa_costmap_bridge import grid, M


def test_grid_ingestion_continues_during_old_frame_evaluation():
    g = guard()
    collision = g.collision
    entered,resume = threading.Event(),threading.Event()
    result = []
    def delayed(command,age,horizon,frame=None):
        entered.set(); assert resume.wait(2)
        return collision(command,age,horizon,frame)
    g.collision = delayed
    worker = threading.Thread(target=lambda:result.append(g.limit((.1,0.,0.),100.02)))
    worker.start(); assert entered.wait(1)
    try:
        assert g.update(scene([(.4,0,.2)],stamp=100.2),100.21)
        assert g.stamp == 100.2
    finally:
        resume.set();worker.join(2)
    assert not worker.is_alive()
    assert result[0][0] == 1.
    assert g.evaluated_frame.stamp == 100.
    assert g.healthy(100.3) and not g.evaluated_fresh(100.3)
    assert not g.xyz.flags.writeable


def test_actual_gate_never_dates_an_old_decision_with_a_new_snapshot():
    from test_factory_voa_mode import FactoryGateTests
    f = FactoryGateTests();f.setUp()
    try:
        g=f.gate;g.require_local_grid_stop=True;g.local_safety=guard(stamp=10.)
        g.local_safety_diagnostics=g.create_publisher(NS,'/patrol/voa/local_safety',1)
        g.counts['/patrol/voa/grid_map']=1;f.heartbeat()
        assert f.arm().success
        g.goal_active_callback(NS(data=True))
        command=f.module.Twist();command.linear.x=.1;g.raw_callback(command)
        collision=g.local_safety.collision
        def arriving(command,age,horizon,frame=None):
            g.clock_time=10.3
            g.local_safety.update(scene([(.4,0,.2)],stamp=10.29),10.3)
            return collision(command,age,horizon,frame)
        g.local_safety.collision=arriving
        g.timer_callback()
        assert f.output()==(0.,0.,0.) and g.armed
        report=json.loads(g.outputs['/patrol/voa/local_safety'][-1].data)
        assert report['source_stamp']==10. and report['latest_source_stamp']>10.2
        assert report['scale']==0.
        g.local_safety.collision=collision;f.heartbeat(10.3)
        g.timer_callback()
        assert f.output()==(0.,0.,0.)
    finally:
        f.doCleanups()


def test_projection_does_not_block_receiving_or_fill_both_executor_workers():
    from test_voa_costmap_bridge import RuntimeTests
    f=RuntimeTests();f.setUp()
    try:
        b=f.bridge;f.now.return_value=100.15;f.tf_until=101.
        b.receive(grid(stamp=100.))
        lookup=b.buffer.lookup_transform
        entered,resume=threading.Event(),threading.Event()
        def slow(*args):
            entered.set(); assert resume.wait(2)
            return lookup(*args)
        b.buffer.lookup_transform=slow
        worker=threading.Thread(target=b.publish);worker.start();assert entered.wait(1)
        try:
            b.receive(grid(stamp=100.1))
            # Another timer must skip, rather than wait on the publishing lock.
            start=time.monotonic();b.publish();assert time.monotonic()-start<.1
            assert b.last_received==100.1
        finally:
            resume.set();worker.join(2)
        assert not worker.is_alive()
        assert M.stamp_seconds(f.outputs[M.TOPIC][-1].header.stamp)==100.
        b.buffer.lookup_transform=lookup;b.publish()
        assert M.stamp_seconds(f.outputs[M.TOPIC][-1].header.stamp)==100.1
    finally:
        f.doCleanups()


def test_close_obstacle_allows_safe_new_heading_but_not_hard_contact():
    straight=guard([(.55,0.,.2)])
    assert straight.limit((.15,0.,0.),100.02)[0]<1.
    turn=guard([(.55,0.,.2)])
    assert turn.limit((.02,0.,-.4),100.02)[0]==1.
    touching=guard([(.30,0.,.2)])
    scale,reason=touching.limit((.02,0.,-.4),100.02)
    assert scale==0. and 'manual_clearance_required' in reason
    assert touching.evaluated_frame.clearance<0.


def test_narrow_clearance_is_not_obtained_by_shrinking_the_robot():
    for width in (.75,.85,1.0):
        walls=[(x,y,.2) for x in np.arange(-.5,1.5,.05) for y in (-width/2,width/2)]
        g=guard(walls)
        assert (g.hx,g.hy)==(.35,.25)
        assert g.limit((.1,0.,0.),100.02)[0]==1.
    too_narrow=guard([(0.,.24,.2),(0.,-.24,.2)])
    assert too_narrow.limit((.1,0.,0.),100.02)[0]==0.


def test_same_narrow_passage_stops_when_pose_age_consumes_clearance():
    walls=[(x,y,.2) for x in np.arange(-.5,1.5,.05) for y in (-.375,.375)]
    fresh=guard(walls)
    assert fresh.limit((.1,0.,0.),100.02)[0]==1.
    aged=guard(walls)
    assert aged.healthy(100.22)  # Still within hard source-age limit.
    assert aged.limit((.1,0.,0.),100.22)[0]==0.  # Uncertainty uses the clearance.


def test_2d_marking_origin_uses_projecting_pose_and_synthetic_height_only():
    from test_voa_costmap_bridge import transform
    pose=transform(yaw=.4,pitch=.2,x=7.,y=-2.)
    pose.translation.z=10.
    xyz,q=M.marking_origin(pose)
    np.testing.assert_allclose(xyz,[7.,-2.,.5])
    np.testing.assert_allclose(q,[0.,0.,np.sin(.2),np.cos(.2)])
    # Synthetic marking Z cannot accidentally exclude obstacles by distance
    # merely because the map terrain itself is ten metres above its origin.
    assert np.linalg.norm(np.array([7.2,-2.,.5])-xyz)<.3


def test_marking_origin_failure_cannot_emit_cloud_or_heartbeat():
    from test_voa_costmap_bridge import RuntimeTests
    f=RuntimeTests();f.setUp()
    try:
        seen=[]
        def fail(stamp,pose):
            seen.append(M.stamp_seconds(stamp));raise RuntimeError('TF publisher failed')
        f.bridge.origin_publisher=fail
        f.bridge.receive(grid(stamp=100.));f.bridge.publish()
        assert seen==[100.] and not f.outputs[M.TOPIC] and not f.outputs[M.HEARTBEAT]
    finally:f.doCleanups()
